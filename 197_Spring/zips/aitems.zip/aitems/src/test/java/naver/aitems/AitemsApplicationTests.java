package naver.aitems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AitemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
